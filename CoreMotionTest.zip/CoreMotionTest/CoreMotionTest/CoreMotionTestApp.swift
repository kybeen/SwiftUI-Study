//
//  CoreMotionTestApp.swift
//  CoreMotionTest
//
//  Created by 김영빈 on 2023/07/01.
//

import SwiftUI

@main
struct CoreMotionTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
